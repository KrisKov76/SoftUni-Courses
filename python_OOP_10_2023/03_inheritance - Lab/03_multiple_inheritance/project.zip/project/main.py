from project.teacher import Teacher

t = Teacher()
print(t.get_fired())
print(t.teach())
print(t.sleep())