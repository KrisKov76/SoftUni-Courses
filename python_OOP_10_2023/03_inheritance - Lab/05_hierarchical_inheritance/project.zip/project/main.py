from project.cat import Cat
from project.dog import Dog

d = Dog()
c = Cat()

print(d.bark())
print(d.eat())
print(c.meow())
print(c.eat())