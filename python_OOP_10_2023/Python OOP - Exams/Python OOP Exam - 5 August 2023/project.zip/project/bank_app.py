class BankApp:
    def __init_(self, capacity):
        self.capacity = capacity
        self.loans = []
        self.clients = []

    def add_loan(self, loan_type: str):
        if loan_type not in ['StudentLoan', 'MortgageLoan']:
            raise Exception("Invalid loan type!")
        self.loans.append(loan_type)
        return f"{loan_type} was successfully added."

    def add_client(self, client_type: str, client_name: str, client_id: str, income: float):
        if client_type not in ["Student", "Adult"]:
            raise Exception("Invalid client type!")
        if len(self.clients) >= self.capacity:
            return "Not enough bank capacity."

        new_client = {
            'client_type': client_type,
            'client_name': client_name,
            'client_id': client_id,
            'income': income
        }
        self.clients.append(new_client)

        return f"{client_type.capitalize()} was successfully added."


    def grant_loan(self, loan_type: str, client_id: str):
        pass

    def remove_client(self, client_id: str):
        pass

    def increase_loan_interest(self, loan_type: str):
        pass

    def increase_clients_interest(self, min_rate: float):
        pass

    def get_statistics(self):
        pass
