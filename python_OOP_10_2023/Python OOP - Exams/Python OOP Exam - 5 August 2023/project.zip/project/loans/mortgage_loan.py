from project.loans.base_loan import BaseLoan


class MortgageLoan(BaseLoan):
    interest_rate = 0.035
    amount = 50000

    def __init__(self, interest_rate, amount):
        super().__init__(interest_rate, amount)

    def increase_interest_rate(self):
        self.interest_rate *= 0.05
