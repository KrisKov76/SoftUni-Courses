from project.loans.base_loan import BaseLoan


class StudentLoan(BaseLoan):
    interest_rate = 0.015
    amount = 2500

    def __init__(self, interest_rate, amount):
        super().__init__(interest_rate, amount)

    def increase_interest_rate(self):
        self.interest_rate *= 1.02
